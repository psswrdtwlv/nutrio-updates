var a="/assets/brotli_dec_wasm_bg-BK3DOf3U.wasm";export{a as default};
