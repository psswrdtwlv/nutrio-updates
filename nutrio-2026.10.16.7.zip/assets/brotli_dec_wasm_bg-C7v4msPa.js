const s="/assets/brotli_dec_wasm_bg-BK3DOf3U.wasm";export{s as default};
