/* ==========================================================================
   NUTRIO — service worker
   App-shell caching only. The app itself is local-first: the diary, weights
   and recipes live in localStorage, so offline means "no network needed",
   not "a cached copy of a server page".
   ========================================================================== */

const VERSION = 'nutrio-v2';
const SHELL = `${VERSION}-shell`;
const ASSETS = `${VERSION}-assets`;

/** Files that must exist for a cold offline start. */
const SHELL_FILES = ['/', '/index.html', '/manifest.webmanifest', '/icons/icon-192.png'];

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches
      .open(SHELL)
      .then((cache) => cache.addAll(SHELL_FILES))
      .then(() => self.skipWaiting())
      .catch(() => self.skipWaiting()),
  );
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches
      .keys()
      .then((keys) =>
        Promise.all(keys.filter((k) => !k.startsWith(VERSION)).map((k) => caches.delete(k))),
      )
      .then(() => self.clients.claim()),
  );
});

self.addEventListener('message', (event) => {
  if (event.data === 'skip-waiting') self.skipWaiting();
});

self.addEventListener('fetch', (event) => {
  const { request } = event;
  if (request.method !== 'GET') return;

  const url = new URL(request.url);
  if (url.origin !== self.location.origin) return;

  /*
   * Catalog traffic is deliberately NOT cached here.
   *
   * The proxy already caches, and it knows when its answers went stale. A
   * service-worker copy would outlive that decision, so a corrected nutrition
   * figure could keep serving for weeks. Worse, it would make an outage
   * invisible: a 503 must reach the UI so the user is told "unavailable"
   * instead of "no such product".
   */
  // Auth and encrypted account responses must never be cached across sessions.
  if (/^\/(?:api|auth|account)(?:\/|$)/.test(url.pathname)) return;

  // Navigations: try the network, fall back to the cached shell so a deep
  // link still opens with no connection. Anything that is not a success counts
  // as "no connection" — a dying server often answers 502 rather than throwing,
  // and an offline-first app should still boot.
  if (request.mode === 'navigate') {
    event.respondWith(
      (async () => {
        try {
          const res = await fetch(request);
          if (res.ok) {
            const copy = res.clone();
            caches.open(SHELL).then((cache) => cache.put('/index.html', copy)).catch(() => {});
            return res;
          }
        } catch {
          /* the network is gone, serve the shell below */
        }
        return (await caches.match('/index.html')) || (await caches.match('/')) || Response.error();
      })(),
    );
    return;
  }

  // Hashed build assets: cache-first, they are immutable.
  const isHashedAsset = /\/assets\/.+\.(js|css|woff2?|png|jpg|svg)$/.test(url.pathname);

  event.respondWith(
    caches.match(request).then((hit) => {
      if (hit && isHashedAsset) return hit;
      return fetch(request)
        .then((res) => {
          if (res && res.ok && res.type === 'basic') {
            const copy = res.clone();
            caches.open(ASSETS).then((cache) => cache.put(request, copy)).catch(() => {});
            return res;
          }
          /* A bad gateway is a failed fetch in every way that matters here. */
          return hit || res;
        })
        .catch(() => hit);
    }),
  );
});
